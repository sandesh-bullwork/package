from setuptools import setup
setup(name="packageaa",
version="0.0.1",
description="abc",
long_description="long description",
author="SN",
packages=['package'],
url="https://github.com/sandesh-bullwork/package",
install_requires=[])


# pypi-AgEIcHlwaS5vcmcCJDMyNzcxMThiLTJmM2UtNDhkYi1hZjRhLWE5YWU3MGYwMTYyOQACKlszLCJiYWMxMjRhMC0yMzY4LTQ3OWMtODMwNi0wNTM1NDhhOGI0NjUiXQAABiBarntUIW5Diwxo1_P2WWFUGPdSNJSsa2eGPg8GqwLbDg