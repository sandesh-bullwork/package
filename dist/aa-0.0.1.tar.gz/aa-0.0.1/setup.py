from setuptools import setup
setup(name="aa",
version="0.0.1",
description="abc",
long_description="long description",
author="SN",
packages=['package'],
install_requires=[])