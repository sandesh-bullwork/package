class bullworkab:
    def a(self):
        print("package opened")
        
    def b(self,num1,num2):
        return num1 * num2